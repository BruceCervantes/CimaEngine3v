//
// Created by andrey on 9/25/25.
//

#ifndef CIMAENGINE3V_JCOMPONENTES_H
#define CIMAENGINE3V_JCOMPONENTES_H


class JComponentes
{
};


#endif //CIMAENGINE3V_JCOMPONENTES_H