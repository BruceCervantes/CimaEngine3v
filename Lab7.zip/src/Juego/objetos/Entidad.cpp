#include "Entidad.hpp"
#include "../../Motor/Componentes/IComponentes.hpp"

namespace IVJ {

    void Entidad::onUpdate(float dt) {

        if (tieneComponente<CE::ISprite>()) {
            auto sprite = getComponente<CE::ISprite>();
            auto pos = getTransformada()->posicion;
            sprite->m_sprite.setPosition({pos.x, pos.y});
        }
    }

    void Entidad::draw(sf::RenderTarget &target, sf::RenderStates state) const {

        state.transform *= getTransform();

        if (tieneComponente<CE::ISprite>()) {

            auto sprite = getComponente<CE::ISprite>();
            target.draw(sprite->m_sprite);
        }
    }
}