#include "EscenaCuadro.hpp"
#include "../Figuras/Figura.hpp"
#include "../../Motor/Camaras/CamarasGestor.hpp"
#include "../../Motor/Primitivos/GestorEscenas.hpp"
#include "../../Motor/Render/Render.hpp"
#include "../../Motor/Primitivos/GestorAssets.hpp"
#include "../Sistema/Sistema.hpp"
#include "../../Motor/Primitivos/Escena.hpp"
#include "../objetos/Entidad.hpp"
#include "../objetos/TileMap.hpp"
#include <memory>
#include <random>
#include <iostream>

namespace IVJ {

void EscenaCuadros::onInit() {
    if (!inicializar) return;

    CE::GestorAssets::Get().agregarTextura("hamilton", ASSETS "/sprites_aliens/F1(Hamilton)-Sheet.png",CE::Vector2D{0,0},CE::Vector2D{64,96});

    CE::GestorAssets::Get().agregarTextura("mapa", ASSETS "/atlas/Mapa(AustriaCapas).png",CE::Vector2D{0,0},CE::Vector2D{5000,3000});

    CE::GestorAssets::Get().agregarTextura("distancia",
            ASSETS "/sprites_aliens/enemies.png",
            CE::Vector2D{0,0},CE::Vector2D{66,92});


    CE::GestorAssets::Get().agregarTextura("cuerpo",
        ASSETS "/sprites_aliens/enemies.png",
        CE::Vector2D{0,0},CE::Vector2D{1080,720});


    //if (!bg[0].loadTileMap(ASSETS "/atlas/mapa_1_layer_1.txt"))
    //    exit(EXIT_FAILURE);
    //if (!bg[1].loadTileMap(ASSETS "/atlas/mapa_1_layer_2.txt"))
    //    exit(EXIT_FAILURE);

    // 🔹 Registro de controles
    registrarBotones(sf::Keyboard::Scan::W, "arriba");
    registrarBotones(sf::Keyboard::Scan::Up, "arriba");
    registrarBotones(sf::Keyboard::Scan::S, "abajo");
    registrarBotones(sf::Keyboard::Scan::Down, "abajo");
    registrarBotones(sf::Keyboard::Scan::A, "izquierda");
    registrarBotones(sf::Keyboard::Scan::Left, "izquierda");
    registrarBotones(sf::Keyboard::Scan::D, "derecha");
    registrarBotones(sf::Keyboard::Scan::Right, "derecha");
    registrarBotones(sf::Keyboard::Scan::Escape, "circulos");

    jugador = std::make_shared<Entidad>();
    jugador->getStats()->hp = 100;
    jugador->setPosicion(0.f, 0.f);
    jugador->addComponente(std::make_shared<CE::ISprite>(CE::GestorAssets::Get().getTextura("hamilton"),.5f));


    mapa = std::make_shared<Entidad>();
    mapa->getStats()->hp = 100;
    mapa->setPosicion(0.f, 0.f);
    mapa->addComponente(std::make_shared<CE::ISprite>(CE::GestorAssets::Get().getTextura("mapa"),1.f));


    // ==================== CREACIÓN DE 100 ENEMIGOS ALEATORIOS ====================
    srand(static_cast<unsigned>(time(nullptr)));

    // Lista de sprites posibles
    std::vector<std::string> sprites = {"distancia"};

    // Creamos 100 enemigos con sprite, posición, velocidad y escala aleatoria
    for (int i = 0; i < 100; ++i) {
        auto enemigo = std::make_shared<Entidad>();
        enemigo->getStats()->hp = 100;

        // Sprite aleatorio
        std::string textura = sprites[rand() % sprites.size()];
        float escala = 1.0f;
        enemigo->addComponente(std::make_shared<CE::ISprite>(
            CE::GestorAssets::Get().getTextura(textura), escala));

        // Posición aleatoria dentro de pantalla
        float posX = static_cast<float>(rand() % 1920);
        float posY = static_cast<float>(rand() % 1080);
        enemigo->setPosicion(posX, posY);

        // Velocidad inicial aleatoria
        auto trans = enemigo->getTransformada();
        trans->velocidad.x = (rand() % 2 == 0 ? -1.f : 1.f) * (50.f + rand() % 150); // entre -200 y 200
        trans->velocidad.y = (rand() % 2 == 0 ? -1.f : 1.f) * (50.f + rand() % 150);

        enemigos.agregarPool(enemigo);
    }
    objetos.agregarPool(mapa);
    objetos.agregarPool(jugador);


    // 🔹 Creación de tres figuras rectangulares
    auto fig1 = std::make_shared<Rectangulo>("Rectangulo",
        100, 100,500.f,700.f ,sf::Color(255, 0, 0, 255), sf::Color(0, 0, 0, 255));
    fig1->setPosicion(300, 400);
    fig1->getStats()->hp = 100;

    auto fig2 = std::make_shared<Rectangulo>("Rectangulo",
        200, 100, 350.f,400.f,sf::Color(169, 169, 0, 255), sf::Color(0, 0, 0, 255));
    fig2->setPosicion(100, 100);
    fig2->getStats()->hp = 100;

    auto fig3 = std::make_shared<Rectangulo>("Rectangulo",
        100, 200,100.f,200.f ,sf::Color(0, 0, 255, 255), sf::Color(0, 0, 0, 255));
    fig3->setPosicion(300, 600);
    fig3->getStats()->hp = 100;

    // 🔹 Añadimos las figuras al pool de objetos
    /*objetos.agregarPool(fig1);
    objetos.agregarPool(fig2);
    objetos.agregarPool(fig3);
    */
    // 🔹 Cámara


    CE::GestorCamaras::Get().agregarCamara(
        std::make_shared<CE::CamaraCuadro>(
            CE::Vector2D{2500, 1500}, CE::Vector2D{5000, 3000}));
    CE::GestorCamaras::Get().setCamaraActiva(1);

    // La cámara sigue al objeto 2
    CE::GestorCamaras::Get().getCamaraActiva().lockEnObjeto(jugador);

    inicializar = false;
}

void EscenaCuadros::onFinal() { }

void EscenaCuadros::onUpdate(float dt) {
    MoverJugador(objetos.getPool(),dt, 3000, 5000);
    SistemaMovimientoEnemigo(enemigos.getPool(),dt);
    //SistemaMovimientoEntes(objetos.getPool(), dt);

    for (auto& f : objetos.getPool())
        f->onUpdate(dt);

    for (auto& e : enemigos.getPool())
        e->onUpdate(dt);

    objetos.borrarPool();
    enemigos.borrarPool();
}

void EscenaCuadros::onInputs(const CE::Botones& accion) {
    auto p = jugador->getTransformada();

    if (accion.getTipo() == CE::Botones::TipoAccion::OnPress) {
        if (accion.getNombre() == "arriba")
            p->velocidad.y = -200;
        else if (accion.getNombre() == "derecha")
            p->velocidad.x = 200;
        else if (accion.getNombre() == "abajo")
            p->velocidad.y = 200;
        else if (accion.getNombre() == "izquierda")
            p->velocidad.x = -200;
        else if (accion.getNombre() == "circulos")
            CE::GestorEscenas::Get().cambiarEscena("Circulos");
    }
    else if (accion.getTipo() == CE::Botones::TipoAccion::OnRelease) {
        if (accion.getNombre() == "arriba" || accion.getNombre() == "abajo")
            p->velocidad.y = 0;
        else if (accion.getNombre() == "derecha" || accion.getNombre() == "izquierda")
            p->velocidad.x = 0;
    }
}

void EscenaCuadros::onRender() {

    for (auto& b: bg)
        CE::Render::Get().AddToDraw(b);

    for (auto& f : objetos.getPool())
        CE::Render::Get().AddToDraw(*f);

    for (auto& e : enemigos.getPool())
        CE::Render::Get().AddToDraw(*e);

}

}
