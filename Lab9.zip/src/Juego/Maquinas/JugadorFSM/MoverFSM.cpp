#include "MoverFSM.hpp"
#include "IdleFSM.hpp"

namespace IVJ {

    MoverFSM::MoverFSM(bool flip_sprite)
        :FSM{}, flip{flip_sprite} {

        nombre = "MoverFSM";
        std::cout<<nombre<<"\n";
    }

    FSM* MoverFSM::onInputs(const CE::IControl& control) {

        if (!control.arr && !control.abj && !control.der && !control.izq)
            return new IdleFSM();
        if (control.der)
            flip = false;
        else if (control.izq)
            flip = true;
        return nullptr;
    }

    void MoverFSM::onEntrar(const Entidad& obj) {

        auto c_sprite = obj.getComponente<CE::ISprite>();
        sprite = &c_sprite->m_sprite;
        s_w = c_sprite->width;
        s_h = c_sprite->height;

        ani_frames[0] = {69.f, 96.f};
        ani_frames[1] = {0.f, 96.f};
        max_tiempo = 0.f;
        tiempo = max_tiempo;
        id_actual = 0;
        flipSprite(obj);
    }

    void MoverFSM::flipSprite(const Entidad& obj) {

        auto c_sprite = obj.getComponente<CE::ISprite>();
        if (flip)
            sprite->setScale({-c_sprite->escala, c_sprite->escala});
        else
            sprite->setScale({c_sprite->escala, c_sprite->escala});

    }

    void MoverFSM::onSalir(const Entidad& obj) {}
    void MoverFSM::onUpdate(const Entidad& obj, float dt) {

        tiempo = tiempo - 1 * dt;
        flipSprite(obj);
        if (tiempo <= 0) {
            sprite->setTextureRect(
                sf::IntRect{
                    {
                        (int)ani_frames[id_actual%4].x,
                        (int)ani_frames[id_actual%4].y
                    },
                {
                    s_w,
                    s_h
                }});
            tiempo = max_tiempo;
            id_actual++;
        }
    }
}