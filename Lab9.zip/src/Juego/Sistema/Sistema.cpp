#include "Sistema.hpp"
#include "../../Motor/Componentes/IComponentes.hpp"
#include "Juego/Figuras/Figura.hpp"
#include <cmath>

#include "Juego/objetos/Entidad.hpp"

namespace IVJ
{

    void MoverJugador(const std::vector<std::shared_ptr<CE::Objeto>>& entes, float dt, float altoVentana, float anchoVentana)
   {
       for (auto& e : entes)
       {
           if (auto jugador = std::dynamic_pointer_cast<IVJ::Entidad>(e))
           {
               auto trans = jugador->getTransformada();

               // Movimiento controlado en ambos ejes
               trans->posicion.x += trans->velocidad.x * dt;
               trans->posicion.y += trans->velocidad.y * dt;

               // Limitar el movimiento dentro de la ventana
               if (trans->posicion.x < 0.f)
                   trans->posicion.x = 0.f;
               if (trans->posicion.x > anchoVentana)
                   trans->posicion.x = anchoVentana;

               if (trans->posicion.y < 0.f)
                   trans->posicion.y = 0.f;
               if (trans->posicion.y > altoVentana)
                   trans->posicion.y = altoVentana;
           }
       }

   }


       void SistemaMovimientoEnemigo(const std::vector<std::shared_ptr<CE::Objeto>> &entes, float dt) {
           for (auto& e : entes)
           {
               auto trans = e->getTransformada();
               if (!trans) continue;

               // Inicializa velocidad si es cero
               if (trans->velocidad.magnitud() == 0)
                   trans->velocidad = CE::Vector2D{300.f, 300.f};

               // Actualiza posición
               trans->posicion.x += trans->velocidad.x * dt;
               trans->posicion.y += trans->velocidad.y * dt;

               // Rebote en ventana
               if (trans->posicion.x < 0 || trans->posicion.x > 1920)
                   trans->velocidad.x *= -1;
               if (trans->posicion.y < 0 || trans->posicion.y >1080 )
                   trans->velocidad.y *= -1;
           }
       }




}
