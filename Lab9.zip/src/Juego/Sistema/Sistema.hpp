#pragma once

#include <vector>
#include <memory>
#include "Juego/Figuras/Figura.hpp"

namespace IVJ {

    void SistemaMovimientoEnemigo(const std::vector<std::shared_ptr<CE::Objeto>> &entes, float dt);
    void MoverJugador(const std::vector<std::shared_ptr<CE::Objeto>>& e, float dt, float altoVentana, float anchoVentana);

} // namespace IVJ
