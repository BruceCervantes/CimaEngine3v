#include "Sistema.hpp"
#include "../../Motor/Componentes/IComponentes.hpp"
#include "Juego/Figuras/Figura.hpp"
#include <cmath>

#include "Juego/objetos/Entidad.hpp"

namespace IVJ
{
   void MoverRectangulo(const std::vector<std::shared_ptr<CE::Objeto>>& entes, float dt, float altoVentana)
    {
       for (auto& e : entes)
       {
           if (auto rect = std::dynamic_pointer_cast<IVJ::Rectangulo>(e))
           {
               auto trans = e->getTransformada();
               trans->posicion.y += trans->velocidad.y * dt;

               if (trans->posicion.y < 0 || trans->posicion.y > altoVentana)
               {
                   trans->velocidad.y = -trans->velocidad.y;
               }
           }
       }
       /*
        auto trans = e->getTransformada();
        trans->posicion.y += trans->velocidad.y * dt;

        if (trans->posicion.y < 0.f || trans->posicion.y > altoVentana)
            trans->velocidad.y = -trans->velocidad.y;
        */
    }

    void MoverTriangulo(std::shared_ptr<CE::Objeto> e, float dt, float anchoVentana, float altoVentana)
    {

       /*
        auto trans = e->getTransformada();

        trans->posicion.x += trans->velocidad.x * dt;

        float amplitud = 50.f;
        float frecuencia = 2.f;
        trans->posicion.y = (altoVentana / 2.f) + amplitud * std::sin(trans->posicion.x * frecuencia * 0.01f);

        if (trans->posicion.x < 0.f || trans->posicion.x > anchoVentana)
        {
            trans->velocidad.x = -trans->velocidad.x;
        }
        */
    }

    void MoverCirculo(const std::vector<std::shared_ptr<CE::Objeto>>& entes, float dt, float anchoVentana, float altoVentana)
   {
       for (auto& e : entes)
       {
           if (auto circ = std::dynamic_pointer_cast<IVJ::Circulo>(e))
           {
               auto trans = e->getTransformada();

               // Si aún no se inicializó el centro y radio, lo configuramos por defecto
               if (!trans->inicializado) {
                   trans->centroX = trans->posicion.x;
                   trans->centroY = trans->posicion.y;
                   trans->radio   = 50.f;
                   trans->angulo = 0.f;
                   trans->inicializado = true;
               }
               trans->angulo += trans->velocidad.x + dt;

               trans->posicion.x = trans->centroX + trans->radio * std::cos(trans->angulo);
               trans->posicion.y = trans->centroY + trans->radio * std::sin(trans->angulo);

               trans->centroX += trans->velocidad.y * dt;

               if (trans->centroX - trans->radio < 0.f || trans->centroX + trans->radio > anchoVentana) {
                   trans->velocidad.y = -trans->velocidad.y;
               }
           }
       }
       /*
       auto trans = e->getTransformada();

       // Movimiento horizontal base
       trans->posicion.x += trans->velocidad.x * dt;

       // Movimiento circular más lento
       static float angulo = 0.f;              // ángulo en radianes
       float radio = 50.f;                     // radio del círculo
       float velocidadAngular = 1.f;           // menos rápido que antes
       angulo += velocidadAngular * dt;

       // Coordenadas circulares centradas en Y medio
       trans->posicion.y = (altoVentana / 2.f) + radio * std::sin(angulo);
       trans->posicion.x += (radio * 0.2f) * std::cos(angulo);  // factor horizontal reducido

       // Rebote en los bordes
       if (trans->posicion.x < 0.f || trans->posicion.x > anchoVentana)
       {
           trans->velocidad.x = -trans->velocidad.x;
       }

       // Guardar posición previa
       trans->pos_previa = trans->posicion;
       */
   }

    void MoverJugador(const std::vector<std::shared_ptr<CE::Objeto>>& entes, float dt, float altoVentana, float anchoVentana)
   {
       for (auto& e : entes)
       {
           if (auto jugador = std::dynamic_pointer_cast<IVJ::Entidad>(e))
           {
               auto trans = jugador->getTransformada();

               // Movimiento controlado en ambos ejes
               trans->posicion.x += trans->velocidad.x * dt;
               trans->posicion.y += trans->velocidad.y * dt;

               // Limitar el movimiento dentro de la ventana
               if (trans->posicion.x < 0.f)
                   trans->posicion.x = 0.f;
               if (trans->posicion.x > anchoVentana)
                   trans->posicion.x = anchoVentana;

               if (trans->posicion.y < 0.f)
                   trans->posicion.y = 0.f;
               if (trans->posicion.y > altoVentana)
                   trans->posicion.y = altoVentana;
           }
       }
   }


}
