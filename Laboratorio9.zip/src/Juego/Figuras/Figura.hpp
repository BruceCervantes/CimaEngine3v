#pragma once

#include <Motor/Primitivos/Objetos.hpp>
#include <SFML/Graphics.hpp>
#include "../../Motor/Primitivos/Objetos.hpp"
#include <SFML/Graphics.hpp>

namespace  IVJ
{
    class Figuras : public CE::Objeto
    {
        public:
            Figuras( int l, float ejex, float ejey,const sf::Color &relleno,const sf::Color &contorno);
            Figuras(){};
            virtual ~Figuras(){}
            virtual float area() = 0;
            virtual void loadFromFile(std::istream& is)=0;
        protected:
            int lados;
            sf::Color c_relleno;
            sf::Color c_contorno;
    };

    class Rectangulo: public Figuras
    {
        public:
            Rectangulo(std::string nom, float base, float altura, float ejex, float ejey, const sf::Color& relleno, const sf::Color& contorno);
            Rectangulo(){};
            ~Rectangulo(){};
            void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
            float area() override;
            void loadFromFile(std::istream& is) override;
            void onUpdate(float dt) override;

        private:
            sf::RectangleShape imagen;
            float a;
            float b;
    };

    class Circulo: public Figuras
    {
    public:
        Circulo(std::string nom, float radio, float ejex, float ejey ,const sf::Color& relleno, const sf::Color& contorno);
        Circulo(){};
        ~Circulo(){};
        void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
        float area() override;
        void loadFromFile(std::istream& is) override;
        void onUpdate(float dt) override;

        sf::CircleShape imagen;
        float r;
    };


    class Triangulo: public Figuras
    {
    public:
        Triangulo(std::string nom, float lado, float ejex, float ejey,const sf::Color& relleno, const sf::Color& contorno);
        Triangulo(){};
        ~Triangulo(){};
        void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
        float area() override;
        void loadFromFile(std::istream& is) override;
        void onUpdate(float dt) override;
    private:
        sf::CircleShape imagen;
        float a;
    };
}
