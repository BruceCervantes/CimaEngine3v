#include "JComponentes.hpp"

namespace IVJ {

    IMaquinaEstado::IMaquinaEstado() {

        fsm = nullptr;
    }

}