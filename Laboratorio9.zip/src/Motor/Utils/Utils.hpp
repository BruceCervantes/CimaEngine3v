#pragma once
#include <string>
namespace CE{
    struct MotorConfig{
        unsigned int vW=0;
        unsigned int vH=0;
        std::string titulo=" ";
    };

}